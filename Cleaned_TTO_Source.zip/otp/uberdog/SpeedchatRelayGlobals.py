# 2013.08.22 22:15:51 Pacific Daylight Time
# Embedded file name: otp.uberdog.SpeedchatRelayGlobals
NORMAL = 0
CUSTOM = 1
EMOTE = 2
PIRATES_QUEST = 3
TOONTOWN_QUEST = 4
# okay decompyling C:\Users\Maverick\Documents\Visual Studio 2010\Projects\Unfreezer\py2\otp\uberdog\SpeedchatRelayGlobals.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2013.08.22 22:15:51 Pacific Daylight Time
