# 2013.08.22 22:15:30 Pacific Daylight Time
# Embedded file name: otp.level.EditMgr
import EditMgrBase

class EditMgr(EditMgrBase.EditMgrBase):
    __module__ = __name__
# okay decompyling C:\Users\Maverick\Documents\Visual Studio 2010\Projects\Unfreezer\py2\otp\level\EditMgr.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2013.08.22 22:15:30 Pacific Daylight Time
