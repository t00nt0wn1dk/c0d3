# 2013.08.22 22:15:21 Pacific Daylight Time
# Embedded file name: otp.friends.FriendResponseCodes
INVITATION_RESP_OK = 0
INVITATION_RESP_DECLINE = 1
INVITATION_RESP_RETRACT = 2
INVITATION_RESP_CANCEL = 3
INVITATION_RESP_ALREADY_FRIENDS = 4
INVITATION_RESP_NEW_FRIENDS = 5
# okay decompyling C:\Users\Maverick\Documents\Visual Studio 2010\Projects\Unfreezer\py2\otp\friends\FriendResponseCodes.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2013.08.22 22:15:21 Pacific Daylight Time
