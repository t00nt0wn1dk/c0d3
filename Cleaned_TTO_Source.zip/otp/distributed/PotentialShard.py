# 2013.08.22 22:15:20 Pacific Daylight Time
# Embedded file name: otp.distributed.PotentialShard


class PotentialShard():
    __module__ = __name__

    def __init__(self, id):
        self.id = id
        self.name = None
        self.population = 0
        self.welcomeValleyPopulation = 0
        self.active = 1
        self.available = 1
        return
# okay decompyling C:\Users\Maverick\Documents\Visual Studio 2010\Projects\Unfreezer\py2\otp\distributed\PotentialShard.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2013.08.22 22:15:20 Pacific Daylight Time
