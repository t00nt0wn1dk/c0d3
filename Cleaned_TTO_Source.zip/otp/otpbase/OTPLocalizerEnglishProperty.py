# 2013.08.22 22:15:45 Pacific Daylight Time
# Embedded file name: otp.otpbase.OTPLocalizerEnglishProperty
FSenterSecretTextPos = (0, 0, -0.25)
FSgotSecretPos = (0, 0, 0.47)
FSgetSecretButton = 0.06
FSnextText = 1.0
FSgetSecret = (1.55, 1, 1)
FSok1 = (1.55, 1, 1)
FSok2 = (0.6, 1, 1)
FScancel = (0.6, 1, 1)
LTPDdirectButtonYesText = 0.05
LTPDdirectButtonNoText = 0.05
LTPDdirectFrameText = 0.06
SCOsubmenuOverlap = 2.0 / 3
# okay decompyling C:\Users\Maverick\Documents\Visual Studio 2010\Projects\Unfreezer\py2\otp\otpbase\OTPLocalizerEnglishProperty.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2013.08.22 22:15:45 Pacific Daylight Time
