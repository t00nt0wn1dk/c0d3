# 2013.08.22 22:15:50 Pacific Daylight Time
# Embedded file name: otp.speedchat.SpeedChatGlobals
from SCTerminal import SCTerminalSelectedEvent
from SCTerminal import SCTerminalLinkedEmoteEvent
from SCStaticTextTerminal import SCStaticTextMsgEvent
from SCGMTextTerminal import SCGMTextMsgEvent
from SCCustomTerminal import SCCustomMsgEvent
from SCEmoteTerminal import SCEmoteMsgEvent, SCEmoteNoAccessEvent
# okay decompyling C:\Users\Maverick\Documents\Visual Studio 2010\Projects\Unfreezer\py2\otp\speedchat\SpeedChatGlobals.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2013.08.22 22:15:50 Pacific Daylight Time
