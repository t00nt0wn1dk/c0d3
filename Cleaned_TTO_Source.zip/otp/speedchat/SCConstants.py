# 2013.08.22 22:15:47 Pacific Daylight Time
# Embedded file name: otp.speedchat.SCConstants
SCMenuFinalizePriority = 48
SCElementFinalizePriority = 47
# okay decompyling C:\Users\Maverick\Documents\Visual Studio 2010\Projects\Unfreezer\py2\otp\speedchat\SCConstants.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2013.08.22 22:15:47 Pacific Daylight Time
