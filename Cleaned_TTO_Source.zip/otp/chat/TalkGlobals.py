# 2013.08.22 22:15:15 Pacific Daylight Time
# Embedded file name: otp.chat.TalkGlobals
TALK_NONE = 0
TALK_OPEN = 1
TALK_WHISPER = 2
TALK_ACCOUNT = 13
TALK_GM = 14
AVATAR_THOUGHT = 16
TALK_GUILD = 3
TALK_PARTY = 4
TALK_PVP = 5
UPDATE_GUILD = 6
UPDATE_FRIEND = 7
UPDATE_PARTY = 8
UPDATE_PVP = 9
INFO_SYSTEM = 10
INFO_GAME = 11
INFO_AVATAR_UNAVAILABLE = 12
INFO_OPEN = 15
INFO_DEV = 17
INFO_GUILD = 18
# okay decompyling C:\Users\Maverick\Documents\Visual Studio 2010\Projects\Unfreezer\py2\otp\chat\TalkGlobals.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2013.08.22 22:15:15 Pacific Daylight Time
