# 2013.08.22 22:17:32 Pacific Daylight Time
# Embedded file name: toontown.cogdominium.CogdoBoardroomGameBase
from toontown.cogdominium import CogdoBoardroomGameSpec
from toontown.cogdominium import CogdoBoardroomGameConsts as Consts

class CogdoBoardroomGameBase():
    __module__ = __name__

    def getConsts(self):
        return Consts

    def getSpec(self):
        return CogdoBoardroomGameSpec
# okay decompyling C:\Users\Maverick\Documents\Visual Studio 2010\Projects\Unfreezer\py2\toontown\cogdominium\CogdoBoardroomGameBase.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2013.08.22 22:17:32 Pacific Daylight Time
