# 2013.08.22 22:17:45 Pacific Daylight Time
# Embedded file name: toontown.cogdominium.CogdoLevelMgr
from otp.level import LevelMgr
from direct.showbase.PythonUtil import Functor
from toontown.toonbase import ToontownGlobals

class CogdoLevelMgr(LevelMgr.LevelMgr):
    __module__ = __name__
# okay decompyling C:\Users\Maverick\Documents\Visual Studio 2010\Projects\Unfreezer\py2\toontown\cogdominium\CogdoLevelMgr.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2013.08.22 22:17:45 Pacific Daylight Time
