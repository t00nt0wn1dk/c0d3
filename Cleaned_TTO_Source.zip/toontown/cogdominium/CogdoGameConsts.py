# 2013.08.22 22:17:43 Pacific Daylight Time
# Embedded file name: toontown.cogdominium.CogdoGameConsts
from toontown.minigame.MinigameGlobals import getSafezoneId, DifficultyOverrideMult, QuantizeDifficultyOverride, NoDifficultyOverride, getDifficulty
from toontown.minigame.MinigameGlobals import NoTrolleyZoneOverride as NoExteriorZoneOverride
MaxPlayers = 4
MessageLabelBlinkTime = 0.25
MessageLabelFadeTime = 0.25
MemoGuiTextScale = 0.11
MemoGuiTextColor = (1, 1, 0, 1)
ExitDoorMoveDuration = 1.0
LaffRewardMin = 25
LaffRewardRange = 112
LaffPenalty = 50
PenthouseElevatorInPath = '**/elevatorIN_node'
PenthouseElevatorOutPath = '**/elevatorOUT_node'
# okay decompyling C:\Users\Maverick\Documents\Visual Studio 2010\Projects\Unfreezer\py2\toontown\cogdominium\CogdoGameConsts.pyc 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2013.08.22 22:17:43 Pacific Daylight Time
